import React, { useState, useEffect } from 'react';
import './App.css';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  TimeScale,
  Title,
  Tooltip,
  Legend,
  CategoryScale,
} from 'chart.js';
import 'chartjs-adapter-date-fns';
import axios from 'axios';

// Register chart components
ChartJS.register(
  LineElement,
  PointElement,
  LinearScale,
  TimeScale,
  Title,
  Tooltip,
  Legend,
  CategoryScale
);

const App = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [coins, setCoins] = useState([]);
  const [btcHistory, setBtcHistory] = useState(null);

  // Fetch BTC 7-day price chart
  useEffect(() => {
    axios.get('https://api.coingecko.com/api/v3/coins/bitcoin/market_chart', {
      params: {
        vs_currency: 'usd',
        days: 7,
        interval: 'daily',
      },
    }).then(res => {
      const prices = res.data.prices;
      setBtcHistory({
        labels: prices.map(p => new Date(p[0])),
        datasets: [{
          label: 'BTC Price (USD)',
          data: prices.map(p => p[1]),
          fill: true,
          borderColor: '#f7931a',
          backgroundColor: 'rgba(247, 147, 26, 0.2)',
          tension: 0.4,
        }],
      });
    }).catch((error) => console.error('Error fetching historical data:', error));
  }, []);

  // Fetch current prices of Bitcoin + Memecoins
  useEffect(() => {
    axios.get('https://api.binance.com/api/v3/ticker/price')
      .then(res => {
        const wanted = ['BTCUSDT', 'WBTCUSDT', 'DOGEUSDT', 'SHIBUSDT', 'FLOKIUSDT', 'PEPEUSDT'];
        const filtered = res.data.filter(item => wanted.includes(item.symbol));
        setCoins(filtered);
      })
      .catch(err => console.error('Error fetching Binance prices:', err));
  }, []);

  return (
    <div className={`app ${darkMode ? 'dark' : ''}`}>
      <button onClick={() => setDarkMode(!darkMode)} className="toggle-btn">
        {darkMode ? '🌞 Light Mode' : '🌙 Dark Mode'}
      </button>

      <h1>Live Crypto Dashboard</h1>

      <section>
        <h2>BTC 7-Day Chart</h2>
        {btcHistory ? (
          <Line data={btcHistory} options={{ responsive: true }} />
        ) : (
          <p>Loading chart...</p>
        )}
      </section>

      <section>
        <h2> Bitcoin + Memecoin Prices</h2>
        <ul className="coin-list">
          {coins.map((coin) => (
            <li key={coin.symbol}>
              <span>{coin.symbol}</span>
              <strong>${parseFloat(coin.price).toFixed(4)}</strong>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default App;
