const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());

app.get('/api/prices', async (req, res) => {
  try {
    const { data } = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: {
        vs_currency: 'usd',
        order: 'market_cap_desc',
        per_page: 5,
        page: 1,
        sparkline: false
      }
    });
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: 'API failed' });
  }
});

app.listen(5000, () => console.log('🔥 Backend running on http://localhost:5000'));
